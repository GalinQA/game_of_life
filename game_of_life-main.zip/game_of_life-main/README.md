# GAME OF LIFE

Game of life on python with using pygame lib and strange rules =)

![screen](./img/screen.png)

## requirements

> python3.7 >

> pip3 install --upgrade pygame

## run

> python3 main.py
